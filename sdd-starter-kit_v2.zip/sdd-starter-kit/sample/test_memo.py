"""受け入れ基準（specs/001-memo/spec.md）に、番号つきで対応するテスト（最後の検証用を含む）。実行: python -m unittest -v"""
import io
import os
import tempfile
import unittest

import memo


class MemoTest(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        os.environ["MEMO_FILE"] = os.path.join(self.dir.name, "memo.json")

    def tearDown(self):
        self.dir.cleanup()
        os.environ.pop("MEMO_FILE", None)

    def run_cmd(self, *argv):
        out, err = io.StringIO(), io.StringIO()
        code = memo.main(list(argv), out, err)
        return code, out.getvalue(), err.getvalue()

    # 受け入れ基準1：add で追加でき、番号は1から順につく
    def test_add_numbers_from_one(self):
        code, out, _ = self.run_cmd("add", "牛乳を買う")
        self.assertEqual(code, 0)
        self.assertEqual(out.strip(), "追加しました: 1 牛乳を買う")
        _, out2, _ = self.run_cmd("add", "手紙を出す")
        self.assertEqual(out2.strip(), "追加しました: 2 手紙を出す")

    # 受け入れ基準3：メモが無い時、list は専用メッセージを表示
    def test_list_empty(self):
        code, out, _ = self.run_cmd("list")
        self.assertEqual((code, out.strip()), (0, "メモはありません"))

    # 受け入れ基準2：list は「番号 [状態] 内容」を1行ずつ表示
    def test_list_shows_items(self):
        self.run_cmd("add", "牛乳を買う")
        self.run_cmd("add", "手紙を出す")
        _, out, _ = self.run_cmd("list")
        self.assertEqual(out.splitlines(), ["1 [ ] 牛乳を買う", "2 [ ] 手紙を出す"])

    # 受け入れ基準4：done で完了にできる
    def test_done(self):
        self.run_cmd("add", "牛乳を買う")
        code, out, _ = self.run_cmd("done", "1")
        self.assertEqual((code, out.strip()), (0, "1 [x] 牛乳を買う"))
        _, listed, _ = self.run_cmd("list")
        self.assertEqual(listed.strip(), "1 [x] 牛乳を買う")

    # 受け入れ基準5：存在しない番号はエラー（終了コード1）
    def test_done_not_found(self):
        code, _, err = self.run_cmd("done", "9")
        self.assertEqual(code, 1)
        self.assertEqual(err.strip(), "番号 9 は見つかりません")

    # 受け入れ基準6：空の内容の add はエラー（終了コード1）
    def test_add_empty(self):
        code, _, err = self.run_cmd("add", "  ")
        self.assertEqual(code, 1)
        self.assertEqual(err.strip(), "メモの内容を入力してください")

    # 受け入れ基準7：日本語が文字化けせず保存される（エッジケース）
    def test_japanese_roundtrip(self):
        self.run_cmd("add", "こんにちは世界")
        with open(os.environ["MEMO_FILE"], encoding="utf-8") as f:
            self.assertIn("こんにちは世界", f.read())

    # 受け入れ基準8：番号は、途中のメモがあっても重ならない（最大番号+1）
    def test_numbers_do_not_collide(self):
        self.run_cmd("add", "a")
        self.run_cmd("add", "b")
        self.run_cmd("done", "1")
        _, out, _ = self.run_cmd("add", "c")
        self.assertEqual(out.strip(), "追加しました: 3 c")

    # 受け入れ基準9：コマンドなし・未知のコマンドは、使い方を表示（終了コード1）
    def test_usage_for_missing_or_unknown_command(self):
        for argv in ([], ["foo"]):
            with self.subTest(argv=argv):
                code, _, err = self.run_cmd(*argv)
                self.assertEqual(code, 1)
                self.assertEqual(err.strip(), "使い方: memo add <内容> | memo list | memo done <番号>")

    # 受け入れ基準10：done の引数が数字1つでなければ、使い方を表示（終了コード1）
    def test_done_bad_args(self):
        for argv in (["done"], ["done", "1", "2"], ["done", "abc"]):
            with self.subTest(argv=argv):
                code, _, err = self.run_cmd(*argv)
                self.assertEqual(code, 1)
                self.assertEqual(err.strip(), "使い方: memo done <番号>")

    # 受け入れ基準11：完了済みに done しても、エラーにしない（終了コード0）
    def test_done_twice_is_not_error(self):
        self.run_cmd("add", "牛乳を買う")
        self.run_cmd("done", "1")
        code, out, _ = self.run_cmd("done", "1")
        self.assertEqual((code, out.strip()), (0, "1 [x] 牛乳を買う"))

    # 最後の検証：add → list → done → list を順に実行（端から端まで）
    def test_end_to_end(self):
        self.run_cmd("add", "牛乳を買う")
        self.assertEqual(self.run_cmd("list")[1].strip(), "1 [ ] 牛乳を買う")
        self.assertEqual(self.run_cmd("done", "1")[1].strip(), "1 [x] 牛乳を買う")
        self.assertEqual(self.run_cmd("list")[1].strip(), "1 [x] 牛乳を買う")


if __name__ == "__main__":
    unittest.main()
