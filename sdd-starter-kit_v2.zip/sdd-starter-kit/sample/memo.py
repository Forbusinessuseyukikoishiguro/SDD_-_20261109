"""memo: いちばん小さなメモ帳（仕様駆動開発の練習用サンプル）。
仕様は specs/001-memo/spec.md。データは JSON ファイル（既定: ./memo.json、環境変数 MEMO_FILE で変更）。
"""
import json
import os
import sys


def data_path():
    return os.environ.get("MEMO_FILE", "memo.json")


def load():
    path = data_path()
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def save(items):
    with open(data_path(), "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=2)


def cmd_add(args, out, err):
    text = " ".join(args).strip()
    if not text:
        print("メモの内容を入力してください", file=err)
        return 1
    items = load()
    new_id = max([i["id"] for i in items], default=0) + 1
    items.append({"id": new_id, "text": text, "done": False})
    save(items)
    print(f"追加しました: {new_id} {text}", file=out)
    return 0


def cmd_list(args, out, err):
    items = load()
    if not items:
        print("メモはありません", file=out)
        return 0
    for i in items:
        mark = "x" if i["done"] else " "
        print(f"{i['id']} [{mark}] {i['text']}", file=out)
    return 0


def cmd_done(args, out, err):
    if len(args) != 1 or not args[0].isdigit():
        print("使い方: memo done <番号>", file=err)
        return 1
    target = int(args[0])
    items = load()
    for i in items:
        if i["id"] == target:
            i["done"] = True
            save(items)
            print(f"{i['id']} [x] {i['text']}", file=out)
            return 0
    print(f"番号 {target} は見つかりません", file=err)
    return 1


COMMANDS = {"add": cmd_add, "list": cmd_list, "done": cmd_done}


def main(argv, out=sys.stdout, err=sys.stderr):
    if not argv or argv[0] not in COMMANDS:
        print("使い方: memo add <内容> | memo list | memo done <番号>", file=err)
        return 1
    return COMMANDS[argv[0]](argv[1:], out, err)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
