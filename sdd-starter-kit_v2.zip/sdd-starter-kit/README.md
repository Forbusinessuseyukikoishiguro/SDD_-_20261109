# 仕様駆動開発 はじめてキット v2（Claude／Claude Code対応）

うさうさ研修工房 / 初心者向け。**コードを書かせる前に、仕様を書く**練習を、今日から始めるための一式です。

## このキットでできること
- 仕様駆動開発（SDD）の流れ「**仕様 → 計画 → タスク → 実装 → 確認**」を、小さな例で体験する
- **CLAUDE.md に仕様を書いて**（または `@` で読み込んで）、Claude Code に渡す（`docs/07`）
- **スパルタレビュー**（`/spec-spartan`）で、仕様・計画・実装を、21の観点で検査し、合格／不合格／判定保留で判定する（`docs/08`）
- Claude Code が使えなくても、**Claude のチャット**で、仕様づくりの練習ができる

## v2 で変わったこと（旧版を、スパルタレビューして直しました。詳しくは `REVIEW.md`）
| 変更 | 内容 |
|---|---|
| 追加 | 専用コマンド `/spec-spartan` と、観点表（21観点・重大度S0〜S3） |
| 追加 | `docs/07` CLAUDE.md で仕様を渡す（方法A：直接書く／方法B：`@` で読み込む） |
| 追加 | `docs/08` スパルタレビュー |
| 修正 | 読み込み確認を `/context` から **`/memory`** に（公式の記載） |
| 修正 | サンプルの仕様にあった抜け（仕様にない振る舞い・最後の検証・未決事項）を直した。テストは8→12件 |
| 修正 | 仕様の雛形に「未決事項」を追加。タスクに「対応する基準」を追加 |

## 中身
| フォルダ・ファイル | 何が入っているか |
|---|---|
| `docs/01_仕様駆動開発とは.md` | 3分で分かる入門（なぜ仕様が先か） |
| `docs/02_Claude_Codeを始める.md` | インストールから最初の質問まで（公式のクイックスタートに沿って） |
| `docs/03_Claudeのチャットで仕様を作る.md` | Claude Code なしで、仕様をつくる手順 |
| `docs/04_最初の1機能（練習）.md` | サンプルを読み、練習問題（削除機能）に挑戦 |
| `docs/05_つまずき集とFAQ.md` | 困った時の対処 |
| `docs/06_用語集.md` | 用語をやさしく説明 |
| `docs/07_CLAUDE.mdで仕様を渡す.md` | **新**：仕様を CLAUDE.md で渡す2つの方法 |
| `docs/08_スパルタレビュー.md` | **新**：容赦なく判定するレビュー |
| `prompts/プロンプトカード.md` | コピーして使える指示文（10枚） |
| `template/` | **自分のプロジェクトにコピーする一式**（CLAUDE.md・specs の雛形・専用コマンド4つ・観点表・ルール・`gitignore_追記用.txt`） |
| `sample/` | **動く完成例**（メモ帳CLI。仕様・計画・タスク・コード・テスト12件） |
| `REVIEW.md` | **新**：旧版のスパルタレビュー結果 |
| `VERIFY.md` | 何を確認し、何を確認していないか |

`template/gitignore_追記用.txt` は、個人用の `CLAUDE.local.md` を、Git に入れないための1行です。自分の `.gitignore` の末尾に追記してください。

## 5分で試す（Claude Code を使う場合）
1. `docs/02_Claude_Codeを始める.md` の手順で、Claude Code を入れて、ログインする
2. `template/` の中身（`CLAUDE.md`・`specs/`・`.claude/`）を、**自分の練習用フォルダ**にコピーする（隠しフォルダ `.claude` も）
3. そのフォルダで `claude` を起動し、`/memory` で、`CLAUDE.md` が読み込まれたか確認する
4. 小さな機能なら、`CLAUDE.md` の「いまの仕様」に仕様を書く（`prompts/` の 9 番、または `/spec-new` で「CLAUDE.md に書く」と頼む）
5. `/spec-plan` で、計画とタスクを作る → 内容を読んで、おかしい所を直してもらう
6. 「`tasks.md` のタスク1から、実装して。各タスクの後に、テストを実行して結果を見せて」と頼む
7. **`/clear` してから `/spec-spartan`** で、判定してもらう。合格が出るまで、直して繰り返す

## 学ぶ順番のおすすめ
`docs/01` → `sample/` を読む → `docs/02` → `docs/07` → `docs/04`（練習）→ `docs/08` → 自分の小さな機能で `template/` を使う

## 大事な4つの約束
1. **仕様にないものは作らない。** 分からない所は、作る前に質問する
2. **確かめられる形で頼む。** 「テストを実行して、結果を見せて」を、毎回付ける
3. **ずれたら、仕様を先に直す。** コードだけ直さない
4. **合格を決めるのは、人。** AIの検査（スパルタレビュー）は、補助

## 注意
- Claude Code は更新が速く、**バージョンで機能や画面が変わります**。このキットは公式ドキュメントに基づきますが、お使いの版で、手元で試してから使ってください。**専用コマンドの動作は、作者が実機で確かめていません**（`VERIFY.md`）
- 会社のコードで使う時は、社内のセキュリティ・情報管理のルールに従ってください。練習には、ダミーのプロジェクトを使いましょう
- CLAUDE.md は「文脈」で、強制ではありません。必ず守らせたいことは、hook や権限設定で（公式のページを見てください）

## 参考（公式ドキュメント）
- Quickstart：https://code.claude.com/docs/en/quickstart.md
- Install：https://code.claude.com/docs/en/install.md
- How Claude remembers your project（CLAUDE.md など）：https://code.claude.com/docs/en/memory
- Best practices for Claude Code：https://code.claude.com/docs/en/best-practices.md
- Extend Claude with skills：https://code.claude.com/docs/en/skills.md
