# 確認状況（何を確かめて、何を確かめていないか）

作成：2026年11月9日 / うさうさ研修工房（v2）

## 確かめたこと
| 項目 | 方法 | 結果 |
|---|---|---|
| サンプル（メモ帳CLI）のテスト | `python -m unittest -v` を実行（Python 3.12.3） | 12テストが全部通った |
| 受け入れ基準とテストの対応 | `spec.md` の基準1〜11と、`test_memo.py` を突き合わせ | 全基準に対応するテストがある。最後の検証用のテストもある |
| CLAUDE.md の性質・200行・`@` の読み込み・`/compact` 後の扱い・食い違い・HTMLコメント・`/memory` | 公式 memory ページ（https://code.claude.com/docs/en/memory ）の本文を、2026年11月9日に取得して確認 | 記載と一致（`docs/07` の根拠） |
| rules の `paths` の書き方、`CLAUDE.local.md`、hook で強制 | 同上 | 記載と一致 |
| レビュー役が、頼まれると何か報告しがち／plan mode／`/clear`／`Ctrl+G` | 公式 Best practices を読んで確認（v1 作成時と、今回の作成作業中） | 記載と一致 |
| 専用コマンド（skill）の形式 | 公式 Skills の記載と照合：`.claude/skills/<名前>/SKILL.md`、frontmatter の `name`・`description`、フォルダ名がコマンド名 | 形式は記載どおり |
| インストールと最初の起動の手順 | v1 作成時に、公式 Quickstart・Install と照合 | 記載と一致（今回は再取得していない） |
| 個人情報・機密 | キット内の文書を確認 | 実名・連絡先・機密なし（サンプルは、ダミーのメモ帳） |
| 文字コード | 全ファイルが UTF-8 として読めるか、検査 | 問題なし |

## 確かめていないこと（あなたの環境で確かめてください）
- **Claude Code の実機での動作**：`/spec-new`・`/spec-plan`・`/spec-review`・`/spec-spartan` の呼び出し、質問の流れ、観点表（`checklist.md`）を、Skill が正しく読むか、は、作者が実行して確かめていない
- **`@specs/…` の読み込み（方法B）**：公式の記載どおりに書いたが、実機で確かめていない
- **画面の見え方・メッセージ**：バージョンで変わる（`claude --version` で確認）
- **Windows の細かい環境差**：公式の「Set up on Windows」を確認
- **料金・プラン・利用条件**：公式の料金ページを確認
- **Spec Kit との比較**：コマンド名は版で異なる（このキットは Spec Kit を必要としない）

## 公式ドキュメント
- https://code.claude.com/docs/en/memory
- https://code.claude.com/docs/en/best-practices.md
- https://code.claude.com/docs/en/skills.md
- https://code.claude.com/docs/en/quickstart.md
- https://code.claude.com/docs/en/install.md
- https://code.claude.com/docs/en/troubleshoot-install.md

## 更新するとき
- 公式に変更があれば、`template/CLAUDE.md`・専用コマンド・`docs/02`・`docs/07` を見直す
- 実機で動作を確かめたら、この表の「確かめていないこと」を更新する
