# 02 Claude Code を始める

公式のクイックスタート（https://code.claude.com/docs/en/quickstart.md ）に沿った、最小の手順です。**画面や手順は更新されるので、迷ったら公式を見てください。**

## 用意するもの
- ターミナル（またはコマンドプロンプト／PowerShell）
- Claude のアカウント（公式：Claude Pro / Max / Team / Enterprise、または Claude Console）
- 練習用のフォルダ（空でOK）

> ターミナルが初めての方、ターミナルを使わずに始めたい方は、公式の**デスクトップアプリ**（Codeタブ）も選べます。公式の「Desktop quickstart」を見てください。

## ステップ1：インストール
公式の「Native Install」が推奨です。お使いの環境に合わせて、**公式の Quickstart の手順**を使ってください。公式に載っている例：

**macOS／Linux／WSL**
```
curl -fsSL https://claude.ai/install.sh | bash
```
**Windows（PowerShell）**
```
irm https://claude.ai/install.ps1 | iex
```
**Windows（WinGet）**
```
winget install Anthropic.ClaudeCode
```

- Windows は、公式の「Set up on Windows」も確認してください
- 入ったか確認：`claude --version`
- 「`claude` が見つからない」と出たら、公式の「Fix your PATH」を見てください（`docs/05` にも書きました）

## ステップ2：ログイン
```
claude
```
最初の起動で、ログインの画面が出ます。あとから切り替える時は、`/login` です。

## ステップ3：練習用フォルダで起動
```
cd 練習用フォルダ
claude
```
Claude Code は、**ファイルを変更する前に、毎回、許可を求めます**。最初は、内容を読んでから許可しましょう。

## ステップ4：最初の質問（探索）
```
このプロジェクトは何をするものですか？
```
空のフォルダでも動きます。コードがあれば、読んで説明してくれます。

## ステップ5：このキットのテンプレートを入れる
1. このキットの `template/` の中身（`CLAUDE.md`・`specs/`・`.claude/`）を、練習用フォルダにコピーします
2. **隠しフォルダ `.claude` も、忘れずにコピー**します（Windowsは、エクスプローラーの「隠しファイル」を表示）
3. `claude` を、そのフォルダで起動し直します
4. 読み込まれたか確認：`/memory` と入力 → 読み込まれた `CLAUDE.md` や rules の一覧が出ます（公式の記載）。一覧に `CLAUDE.md` があればOK
5. `/` を入力して、`spec-new`・`spec-plan`・`spec-review`・`spec-spartan` が候補に出れば、専用コマンドも使えます

## 便利な操作（覚えておくと安心）
| 操作 | 意味 |
|---|---|
| `Shift+Tab` | 許可の方式（モード）を切り替える。**plan mode** にすると、ファイルを変更せずに計画だけできる |
| `Ctrl+G` | 計画を、自分のエディタで直接直す |
| `/clear` | 会話をリセットする（仕様ができたら、実装は新しい会話で） |
| `/memory` | 読み込まれた CLAUDE.md や rules を見る（ここで確認する） |
| `/context` | 文脈（コンテキスト）の使われ方を見る |
| `Esc` | 途中で止める |

## うまく動かない時
`docs/05_つまずき集とFAQ.md` を見てください。
